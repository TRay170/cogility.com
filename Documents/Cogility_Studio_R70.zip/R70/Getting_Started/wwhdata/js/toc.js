function  WWHBookData_AddTOCEntries(P)
{
var A=P.fN("Preface","1");
var B=A.fN("About this book","2");
B=A.fN("Cogility Studio documentation","3");
A=P.fN("Set up a Cogility project","4");
B=A.fN("Installation","5");
B=A.fN("Project configuration","6");
var C=B.fN("Setting up a basic project","6#wp1004573");
B=A.fN("Authoring repository","7");
C=B.fN("Configuring an authoring repository","7#wp1004743");
C=B.fN("Loading the authoring repository","7#wp1004899");
A=P.fN("Model development","8");
B=A.fN("Model container","9");
C=B.fN("Creating a model","9#wp1005033");
B=A.fN("Information model","10");
C=B.fN("Class diagrams","10#wp1005132");
C=B.fN("Class attributes","10#wp1005200");
C=B.fN("Class associations","10#wp1005691");
B=A.fN("Behavior model","11");
B=A.fN("Events","12");
B=A.fN("Messages","13");
B=A.fN("Web services","14");
B=A.fN("Transformations","15");
B=A.fN("Business logic","16");
B=A.fN("Change management","17");
A=P.fN("Deployment &amp; execution","18");
B=A.fN("Deployment model","19");
B=A.fN("Push","20");
B=A.fN("Cogility Insight","21");
B=A.fN("Cogility Message Traffic Viewer","22");
B=A.fN("Cogility Web Service Exerciser","23");
B=A.fN("Cogility WatchDog","24");
}
