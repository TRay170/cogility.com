function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("application servers supported",new Array("5#wp999504"));
B=A.fA("authoring repository",new Array("8","8#wp1004049"));
A=P.fA("B",null,null,"002");
B=A.fA("BEA WebLogic configuration",new Array("12#wp1031677"));
A=P.fA("D",null,null,"002");
B=A.fA("databases supported",new Array("5#wp999475"));
A=P.fA("H",null,null,"002");
B=A.fA("hardware requirements",new Array("4"));
A=P.fA("I",null,null,"002");
B=A.fA("IBM WebSphere configuration",new Array("13"));
B=A.fA("installing Cogility Studio",new Array("6"));
A=P.fA("O",null,null,"002");
B=A.fA("operating systems supported",new Array("5#wp999470"));
A=P.fA("P",null,null,"002");
B=A.fA("persistent repository, creating",new Array("8"));
A=P.fA("R",null,null,"002");
B=A.fA("repository");
var C=B.fA("authoring",new Array("8#wp1004049"));
C=B.fA("authoring vs. run time",new Array("8"));
A=P.fA("S",null,null,"002");
B=A.fA("software requirements",new Array("5"));
A=P.fA("U",null,null,"002");
B=A.fA("uninstalling Cogility Studio",new Array("10"));
A=P.fA("W",null,null,"002");
B=A.fA("WebLogic configuration",new Array("12#wp1031677"));
B=A.fA("WebSphere configuration",new Array("13"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
