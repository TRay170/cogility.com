function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("aspect differences",new Array("17#wp1062933","29"));
B=A.fA("aspects");
var C=B.fA("associations",new Array("9#wp1043505"));
C=B.fA("attributes",new Array("9#wp1043493"));
C=B.fA("change aspects",new Array("29#wp1051897"));
C=B.fA("conflict aspects",new Array("30#wp1054077"));
C=B.fA("content",new Array("9#wp1043513"));
C=B.fA("in the User Modification View",new Array("9#wp1043462"));
C=B.fA("superclass",new Array("9#wp1043516"));
B=A.fA("association aspect differences",new Array("9#wp1043505"));
B=A.fA("attribute aspect differences",new Array("9#wp1043493"));
A=P.fA("C",null,null,"002");
B=A.fA("com.cogility.ImportExport.ModelRoot.",new Array("20#wp1061048"));
B=A.fA("com.cogility.ImportExport.PrefersSingleFileOptions",new Array("19#wp1061799"));
B=A.fA("compressed XML",new Array("20#wp1061814"));
B=A.fA("configuration parameters");
C=B.fA("com.cogility.ImportExport.ModelRoot.",new Array("20#wp1061048"));
C=B.fA("com.cogility.ImportExport.PrefersSingleFileOptions",new Array("19#wp1061799"));
B=A.fA("conflicts");
C=B.fA("versioning",new Array("30#wp1066367"));
B=A.fA("conflicts and differences view",new Array("23#wp1060707","23#wp1048385"));
B=A.fA("Conflicts and Differences view",new Array("26#wp1055498"));
B=A.fA("containment conflicts",new Array("30#wp1035310"));
B=A.fA("content aspect differences",new Array("9#wp1043513"));
B=A.fA("Current Model",new Array("26#wp1055498"));
A=P.fA("D",null,null,"002");
B=A.fA("differences");
C=B.fA("aspect",new Array("29"));
C=B.fA("element",new Array("27"));
A=P.fA("E",null,null,"002");
B=A.fA("element differences",new Array("27"));
B=A.fA("element revision history",new Array("17","17#wp1046070"));
A=P.fA("F",null,null,"002");
B=A.fA("force versioning",new Array("10#wp1062763","12","12#wp1062804"));
A=P.fA("G",null,null,"002");
B=A.fA("genealogical order",new Array("17#wp1062849"));
A=P.fA("H",null,null,"002");
B=A.fA("head revision",new Array("18#wp1042423"));
A=P.fA("I",null,null,"002");
B=A.fA("immutable",new Array("6#wp1043035"));
B=A.fA("inverse chronological order",new Array("17#wp1062849"));
A=P.fA("M",null,null,"002");
B=A.fA("modified version",new Array("16#wp1045229"));
B=A.fA("mutable",new Array("6#wp1042796"));
A=P.fA("P",null,null,"002");
B=A.fA("Place Model Under CM button",new Array("4#wp1046035"));
A=P.fA("R",null,null,"002");
B=A.fA("replace model elements",new Array("24#wp1055528"));
B=A.fA("revisions");
C=B.fA("viewing conflicts and differences",new Array("23#wp1060707","23#wp1048385"));
A=P.fA("S",null,null,"002");
B=A.fA("superclass aspect differences",new Array("9#wp1043516"));
B=A.fA("Sync Dividers checkbox",new Array("26#wp1055498"));
A=P.fA("T",null,null,"002");
B=A.fA("turn-over version",new Array("17#wp1062859","18#wp1042236"));
A=P.fA("U",null,null,"002");
B=A.fA("User Modifications view.",new Array("6#wp1058877"));
A=P.fA("V",null,null,"002");
B=A.fA("version",new Array("10#wp1045045"));
B=A.fA("version compare",new Array("23"));
B=A.fA("version conflict",new Array("30","30#wp1066379"));
B=A.fA("version history",new Array("17","17#wp1046070"));
B=A.fA("versioning a model",new Array("13#wp1045256"));
B=A.fA("versioning conflict",new Array("30#wp1066367"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
