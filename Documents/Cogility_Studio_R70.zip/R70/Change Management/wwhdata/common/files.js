function  WWHBookData_Files(P)
{
P.fA("Change Management in Cogility Studio","Change%20Management-1-1.html");
P.fA("Preface","Change%20Management-2-1.html");
P.fA("Cogility Studio documentation","Change%20Management-2-2.html");
P.fA("Change management","Change%20Management-3-1.html");
P.fA("Base-line model","Change%20Management-3-2.html");
P.fA("Change management preferences","Change%20Management-3-3.html");
P.fA("User modifications","Change%20Management-4-1.html");
P.fA("Viewing user modifications","Change%20Management-4-2.html");
P.fA("Element differences","Change%20Management-4-3.html");
P.fA("Aspect differences","Change%20Management-4-4.html");
P.fA("Versions","Change%20Management-5-1.html");
P.fA("Versioning specific artifacts","Change%20Management-5-2.html");
P.fA("Forcing versioning","Change%20Management-5-3.html");
P.fA("Versioning an entire model","Change%20Management-5-4.html");
P.fA("Revising version information","Change%20Management-5-5.html");
P.fA("Duplicate elements and containers","Change%20Management-5-6.html");
P.fA("Modified model","Change%20Management-5-7.html");
P.fA("Version history","Change%20Management-5-8.html");
P.fA("Turn-over version","Change%20Management-5-9.html");
P.fA("Model comparison","Change%20Management-6-1.html");
P.fA("Model export","Change%20Management-6-2.html");
P.fA("Model import","Change%20Management-6-3.html");
P.fA("Repository model import","Change%20Management-6-4.html");
P.fA("Version comparison","Change%20Management-6-5.html");
P.fA("Model element replacement","Change%20Management-6-6.html");
P.fA("Difference report","Change%20Management-6-7.html");
P.fA("Differences and conflicts","Change%20Management-7-1.html");
P.fA("Element differences","Change%20Management-7-2.html");
P.fA("CHANGED elements","Change%20Management-7-3.html");
P.fA("Aspect differences","Change%20Management-7-4.html");
P.fA("Conflicts","Change%20Management-7-5.html");
P.fA("Change Management","Change%20Management-8-1.html");
}
