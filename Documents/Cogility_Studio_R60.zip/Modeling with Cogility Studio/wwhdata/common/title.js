function  WWHBookData_Title()
{
  return "Modeling with Cogility Studio";
}
