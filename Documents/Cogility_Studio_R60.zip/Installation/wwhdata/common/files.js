function  WWHBookData_Files(P)
{
P.fA("Installing Cogility Studio","Installation-1-1.html");
P.fA("Preface","Installation-2-1.html");
P.fA("Cogility Studio documentation","Installation-2-2.html");
P.fA("Cogility Studio","Installation-3-1.html");
P.fA("Hardware requirements","Installation-3-2.html");
P.fA("Software requirements","Installation-3-3.html");
P.fA("Installing Cogility Studio","Installation-3-4.html");
P.fA("Configuration parameters","Installation-3-5.html");
P.fA("Creating the repositories","Installation-3-6.html");
P.fA("Verifying your installation","Installation-3-7.html");
P.fA("Uninstalling Cogility Studio","Installation-3-8.html");
P.fA("Application servers","Installation-4-1.html");
P.fA("BEA WebLogic","Installation-4-2.html");
P.fA("IBM WebSphere","Installation-4-3.html");
P.fA("Oracle Application Server (Standalone Mode)","Installation-4-4.html");
P.fA("Databases","Installation-5-1.html");
P.fA("IBM DB2","Installation-5-2.html");
P.fA("Microsoft SQL Server","Installation-5-3.html");
P.fA("MySQL","Installation-5-4.html");
P.fA("Oracle","Installation-5-5.html");
}
