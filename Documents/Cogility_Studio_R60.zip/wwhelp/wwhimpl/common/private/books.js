// Copyright (c) 2001-2003 Quadralay Corporation.  All rights reserved.
//

function  WWHBookGroups_Books(ParamTop)
{


  ParamTop.fAddDirectory("Action Semantics", null, null, null, null);
  ParamTop.fAddDirectory("Change Management", null, null, null, null);
  ParamTop.fAddDirectory("Getting_Started", null, null, null, null);
  ParamTop.fAddDirectory("Installation", null, null, null, null);
  ParamTop.fAddDirectory("Model Deployment and Execution in Cogility Studio", null, null, null, null);
  ParamTop.fAddDirectory("Modeling with Cogility Studio", null, null, null, null);
  ParamTop.fAddDirectory("Tutorial", null, null, null, null);
}

function  WWHBookGroups_ShowBooks()
{
  return true;
}

function  WWHBookGroups_ExpandAllAtTop()
{
  return false;
}
