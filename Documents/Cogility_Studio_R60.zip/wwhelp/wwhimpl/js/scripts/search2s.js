// Copyright (c) 2000-2003 Quadralay Corporation.  All rights reserved.
//

// Search
//
WWHFrame.WWHSearch.fCheckForMatch(BookData_Search);
