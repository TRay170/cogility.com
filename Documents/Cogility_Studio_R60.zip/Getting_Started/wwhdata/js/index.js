function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("active project",new Array("6#wp1004659"));
B=A.fA("Authoring repository",new Array("7"));
A=P.fA("B",null,null,"002");
B=A.fA("basic project",new Array("6#wp1004659","6#wp1004573"));
B=A.fA("Behavior model",new Array("11"));
B=A.fA("business processes",new Array("11#wp1005874"));
A=P.fA("C",null,null,"002");
B=A.fA("Class associations",new Array("10#wp1005691"));
B=A.fA("Class attributes",new Array("10#wp1005200"));
B=A.fA("Class diagrams",new Array("10#wp1005179"));
B=A.fA("Cogility Message Traffic Viewer",new Array("22#wp1006603"));
B=A.fA("Cogility WatchDog",new Array("24#wp1006730"));
B=A.fA("Cogility Web Service Exerciser",new Array("23#wp1006654"));
A=P.fA("D",null,null,"002");
B=A.fA("Deployment",new Array("18"));
A=P.fA("E",null,null,"002");
B=A.fA("Events",new Array("12"));
A=P.fA("I",null,null,"002");
B=A.fA("Information model",new Array("10"));
B=A.fA("initiate the business process",new Array("12#wp1006542"));
B=A.fA("install Cogility Studio",new Array("5#wp1003642"));
A=P.fA("M",null,null,"002");
B=A.fA("Message artifacts",new Array("13#wp1006336"));
B=A.fA("MIM class",new Array("10#wp1005146"));
B=A.fA("Model container",new Array("9"));
A=P.fA("O",null,null,"002");
B=A.fA("outbound web service",new Array("14#wp1006391"));
A=P.fA("P",null,null,"002");
B=A.fA("Project configuration",new Array("6"));
B=A.fA("project-specific configuration file",new Array("6#wp1004659"));
A=P.fA("S",null,null,"002");
B=A.fA("set up Cogility Studio",new Array("4#wp1003308"));
B=A.fA("state machine",new Array("16#wp1006338"));
A=P.fA("T",null,null,"002");
B=A.fA("Transformations",new Array("15"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 2;
}
