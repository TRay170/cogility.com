function  WWHBookData_Files(P)
{
P.fA("Getting Started with Cogility Studio","Getting_Started-1-1.html");
P.fA("Preface","Getting_Started-2-1.html");
P.fA("About this book","Getting_Started-2-2.html");
P.fA("Cogility Studio documentation","Getting_Started-2-3.html");
P.fA("Set up a Cogility project","Getting_Started-3-1.html");
P.fA("Installation","Getting_Started-3-2.html");
P.fA("Project configuration","Getting_Started-3-3.html");
P.fA("Authoring repository","Getting_Started-3-4.html");
P.fA("Model development","Getting_Started-4-01.html");
P.fA("Model container","Getting_Started-4-02.html");
P.fA("Information model","Getting_Started-4-03.html");
P.fA("Behavior model","Getting_Started-4-04.html");
P.fA("Events","Getting_Started-4-05.html");
P.fA("Messages","Getting_Started-4-06.html");
P.fA("Web services","Getting_Started-4-07.html");
P.fA("Transformations","Getting_Started-4-08.html");
P.fA("Business logic","Getting_Started-4-09.html");
P.fA("Change management","Getting_Started-4-10.html");
P.fA("Deployment &amp; execution","Getting_Started-5-1.html");
P.fA("Deployment model","Getting_Started-5-2.html");
P.fA("Push","Getting_Started-5-3.html");
P.fA("Cogility Insight","Getting_Started-5-4.html");
P.fA("Cogility Message Traffic Viewer","Getting_Started-5-5.html");
P.fA("Cogility Web Service Exerciser ","Getting_Started-5-6.html");
P.fA("Cogility WatchDog","Getting_Started-5-7.html");
}
